var searchData=
[
  ['patron_69',['Patron',['../class_patron.html',1,'']]]
];
