var searchData=
[
  ['sesion_5fvacia_132',['sesion_vacia',['../class_rejilla.html#aa2fef21545ea56c59943aa65977f2895',1,'Rejilla']]],
  ['subarbol_133',['subarbol',['../class_rejilla.html#ae8d43e85c486eadede56bfbc23fdd3f6',1,'Rejilla']]]
];
