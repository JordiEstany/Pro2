var searchData=
[
  ['generar_5flista_5fpatron_32',['generar_lista_patron',['../class_patron.html#a0b1df90a474a54ba609c385381424307',1,'Patron']]]
];
