var searchData=
[
  ['add_5fmsg_1',['add_msg',['../class_cjt___mensajes.html#ab0c73b06a650472f93fd46fd67e4bc9a',1,'Cjt_Mensajes']]],
  ['add_5frejilla_2',['add_rejilla',['../class_cjt___rejillas.html#a0d5fe8ba42a8f143b55addd31dff6393',1,'Cjt_Rejillas']]],
  ['arbolpatron_3',['arbolpatron',['../class_patron.html#a5055c5d014276c7739293bf6d1ee956d',1,'Patron']]]
];
