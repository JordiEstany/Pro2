var searchData=
[
  ['nuevo_5fpatron_124',['nuevo_patron',['../class_cjt___patrones.html#aa625339eba6a6b8d4203ae20e7bc693d',1,'Cjt_Patrones']]]
];
