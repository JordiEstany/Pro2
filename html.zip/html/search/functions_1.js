var searchData=
[
  ['borrar_5fmsg_86',['borrar_msg',['../class_cjt___mensajes.html#a68d4889b39b00e7c073b567cd454da67',1,'Cjt_Mensajes']]]
];
