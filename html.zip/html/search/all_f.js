var searchData=
[
  ['texto_62',['texto',['../class_mensaje.html#ab38e0cffcf7af4cec507b0b138d9c644',1,'Mensaje']]]
];
