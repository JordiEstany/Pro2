var searchData=
[
  ['main_122',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mensaje_123',['Mensaje',['../class_mensaje.html#a7b8b4ca08f400fef32eaffeec00f65b3',1,'Mensaje']]]
];
