var searchData=
[
  ['arbolpatron_127',['arbolpatron',['../class_patron.html#a5055c5d014276c7739293bf6d1ee956d',1,'Patron']]]
];
