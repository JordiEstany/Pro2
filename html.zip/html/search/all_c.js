var searchData=
[
  ['n_53',['n',['../class_rejilla.html#ab0b9df8a469bd69c07d1786082d1a438',1,'Rejilla']]],
  ['nuevo_5fpatron_54',['nuevo_patron',['../class_cjt___patrones.html#aa625339eba6a6b8d4203ae20e7bc693d',1,'Cjt_Patrones']]]
];
