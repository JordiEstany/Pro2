var searchData=
[
  ['vector_5fptr_133',['vector_ptr',['../class_cjt___patrones.html#a08d60cd6bfdfc2fa10544874e819cc50',1,'Cjt_Patrones']]],
  ['vector_5frej_134',['vector_rej',['../class_cjt___rejillas.html#a11864dfa6a5f918d549a9c2c12192fb7',1,'Cjt_Rejillas']]]
];
