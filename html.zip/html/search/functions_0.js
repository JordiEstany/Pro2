var searchData=
[
  ['add_5fmsg_84',['add_msg',['../class_cjt___mensajes.html#ab0c73b06a650472f93fd46fd67e4bc9a',1,'Cjt_Mensajes']]],
  ['add_5frejilla_85',['add_rejilla',['../class_cjt___rejillas.html#a0d5fe8ba42a8f143b55addd31dff6393',1,'Cjt_Rejillas']]]
];
